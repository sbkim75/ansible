#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

function getKhanAgentPath() {
 local KHAN_AGENT_PATH=$1

  for file in $(cat $KHAN_AGENT_PATH/current.version); do
    KHAN_AGENT_FILE="$file"
  done

  echo "$KHAN_AGENT_PATH/$KHAN_AGENT_FILE"
}

function listjars {
  FILES=$(ls $1*.jar)
  echo ${FILES}
}

function getLogmanagerPath {

  JBOSS_HOME=$1
  OVERLAYS_PATH="$JBOSS_HOME/modules/system/layers/base"

  OVERLAYS_PATH="$JBOSS_HOME/modules/system/layers/base/.overlays"
  MODULES_SOURCE_PATHS=("$JBOSS_HOME/modules/system/layers/base" "$JBOSS_HOME")


  if [ -f "$OVERLAYS_PATH/.overlays" ]; then
    for layer in $(tac $OVERLAYS_PATH/.overlays); do
      MODULES_SOURCE_PATHS=("$OVERLAYS_PATH/$layer" ${MODULES_SOURCE_PATHS[@]})
    done
  fi
  name="org/jboss/logmanager/main/"

  for source_dir in "${MODULES_SOURCE_PATHS[@]}"; do
  	if [ -d "$source_dir/${name}" ]; then
  	  files="$(listjars $source_dir/${name})"

  	  if [ -n "$files" ]; then
  	   echo "$files" | sed -e "s/^[ \t]*//" | sed -e "s| |:|g" | sed -e ":a;N;$!ba;s|\n|:|g"
  	   return
  	  fi
  	else
  	  files="$(compgen -G "$source_dir/${name}*.jar")"

  	  if [ -n "$files" ]; then
  	    echo "${files[0]}"
  	    return
  	  fi
  	fi
  done

  echo "Could not find any jar for the $name path, aborting"
  exit 1
}


#R=$(getLogmanagerPath "org/jboss/logmanager/main/" "/svc/test7domain/was/jboss-eap-7.0")
#echo "R: $R"

#echo "$(getKhanAgentPath /svc/test7/was/domains/khan-agent)"