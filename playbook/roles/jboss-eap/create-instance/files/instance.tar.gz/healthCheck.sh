#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

DATE=`date +%Y%m%d%H%M%S`

. ./env.sh

export CONTEXT_NAME=$1

let HTTP_PORT=8080+$PORT_OFFSET

echo ""
echo "Check $HTTP_PORT port ready on $BIND_ADDR "
while [ `netstat -an | grep :$HTTP_PORT | grep LISTEN | wc | awk '{print $1}'` != 1 ]; do
        echo -ne "."
        sleep 1
done

echo ""
echo "Check WAS Context Ready http://$BIND_ADDR:$HTTP_PORT$CONTEXT_NAME"

until [ "`curl --silent --show-error --connect-timeout 1 -I http://$BIND_ADDR:$HTTP_PORT$CONTEXT_NAME | egrep '200|302'`" != "" ];
do
        echo -ne "."
        sleep 1
done
echo "SUCCESS"