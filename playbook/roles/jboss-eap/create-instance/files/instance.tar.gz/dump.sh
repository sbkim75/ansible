#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

. ./env.sh 

for count in 1 2 3 4 5; do
    echo "Thread Dump : $count"
    for i in `ps -ef | grep java | grep "DDOMAIN_GROUP_NAME=$DOMAIN_GROUP_NAME " | grep "SERVER=$SERVER_NAME " | awk '{print $2}'`;do
        export INSTANCE=`ps -ef | grep java | grep "DDOMAIN_GROUP_NAME=$DOMAIN_GROUP_NAME " | grep "SERVER=$SERVER_NAME " | grep $i | gawk '{ match($0, /(Djboss.node.name)=(.*).+/, arr)
print arr[2]  }' | awk '{print $1}' `
        date
        #echo "+kill -3 $i"
        #kill -3 $i
        echo "+jstack -l $i >> $JBOSS_LOG_DIR/nohup/thread_dump.$INSTANCE.$i"
        jstack -l $i >> $JBOSS_LOG_DIR/nohup/thread_dump.$INSTANCE.$i
    done
    sleep 3
done
echo "done"

