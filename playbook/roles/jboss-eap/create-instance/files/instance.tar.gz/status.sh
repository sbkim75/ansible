#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

. ./env.sh 

ps -ef | grep java | grep "DDOMAIN_GROUP_NAME=$DOMAIN_GROUP_NAME " | grep "SERVER=$SERVER_NAME "
