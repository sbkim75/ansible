#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

. ../env.sh

echo "patch apply /sw/jboss/upload/jboss-eap-6.4.8-patch.zip"

$JBOSS_HOME/bin/jboss-cli.sh --connect --controller=$CONTROLLER_IP:$CONTROLLER_PORT --command="patch apply --override-all /sw/jboss/upload/jboss-eap-6.4.8-patch.zip"

