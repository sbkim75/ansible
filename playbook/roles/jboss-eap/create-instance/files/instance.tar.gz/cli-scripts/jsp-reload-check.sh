#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

. ../env.sh

export CHECK_INTERVAL=60

echo ""
echo ">>> /subsystem=web/configuration=jsp-configuration/:write-attribute(name=development,value=true)"
$JBOSS_HOME/bin/jboss-cli.sh --connect --controller=$CONTROLLER_IP:$CONTROLLER_PORT --command="/subsystem=web/configuration=jsp-configuration/:write-attribute(name=development,value=true)"

echo ""
echo ">>> /subsystem=web/configuration=jsp-configuration/:write-attribute(name=check-interval,value=$CHECK_INTERVAL)"
$JBOSS_HOME/bin/jboss-cli.sh --connect --controller=$CONTROLLER_IP:$CONTROLLER_PORT --command="/subsystem=web/configuration=jsp-configuration/:write-attribute(name=check-interval,value=$CHECK_INTERVAL)"

