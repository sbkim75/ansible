#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

. ./env.sh

if [ e$1 = "e--help" ]
then
    echo "Usage: httpdCtl.sh [OPTION]"
    echo "ex)"
    echo "./httpdCtl.sh ACT"
    echo "./httpdCtl.sh STP"
    exit;
fi

if [ e$1 = "e" ]
then
    echo "httpdCtl: missing OPTION"
    echo "ex)"
    echo "./httpdCtl.sh ACT"
    echo "./httpdCtl.sh STP"
    exit;
fi

# mod_jk Turn OFF
if [ e$1 = "eACT" ]
then
    for HTTPD_HOST in "${HTTPD_HOSTS[@]}"
    do
        echo "<<< Turn-ON Worker $SERVER_NAME in $LB_WORKER [$HTTPD_HOST]"
        if [ "`curl --silent --show-error --connect-timeout 1 -I \"http://$HTTPD_HOST:$APACHE_PORT/jkstatus?cmd=update&w=$LB_WORKER&sw=$SERVER_NAME&vwa=0\" | egrep '404|500|503'`" != "" ]
        then
            echo "<<< Error"
        else
            echo "<<< Done"
        fi
    done
fi

# mod_jk Turn ON
if [ e$1 = "eSTP" ]
then
    for HTTPD_HOST in "${HTTPD_HOSTS[@]}"
    do
        echo "<<< Turn-OFF Worker $SERVER_NAME in $LB_WORKER [$HTTPD_HOST]"
        if [ "`curl --silent --show-error --connect-timeout 1 -I \"http://$HTTPD_HOST:$APACHE_PORT/jkstatus?cmd=update&w=$LB_WORKER&sw=$SERVER_NAME&vwa=2\" | egrep '404|500|503'`" != "" ]
        then
            echo "<<< Error"
        else
            echo "<<< Done"
        fi
    done
fi

