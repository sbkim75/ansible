#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

. ./env.sh 

# mod_jk Turn OFF
if [ e$1 = "ewait" ]
then
    for HTTPD_HOST in "${HTTPD_HOSTS[@]}"
    do
        echo "<<< Turn-OFF Worker $SERVER_NAME in $LB_WORKER [$HTTPD_HOST]"
        if [ "`curl --silent --show-error --connect-timeout 1 -I \"http://$HTTPD_HOST:$APACHE_PORT/jkstatus?cmd=update&w=$LB_WORKER&sw=$SERVER_NAME&vwa=2\" | egrep '404|500|503'`" != "" ]
        then
            echo "<<< Error"
        else
            echo "<<< Done"
        fi
    done
    sleep 3
fi

ps -ef | grep java | grep "DDOMAIN_GROUP_NAME=$DOMAIN_GROUP_NAME " | grep "SERVER=$SERVER_NAME " | awk {'print "kill -9 " $2'} | sh -x
