#!/bin/sh
# -------------------------------------------------------------
#   KHAN [provisioning]              http://www.opennaru.com/
#   JBoss EAP 6.4.0
#
#   contact : service@opennaru.com
#   Copyright(C) 2015, opennaru.com, All Rights Reserved.
# -------------------------------------------------------------

DATE=`date +%Y%m%d%H%M%S`

. ./env.sh

PID=`ps -ef | grep java | grep "DDOMAIN_GROUP_NAME=$DOMAIN_GROUP_NAME " | grep "=$SERVER_NAME " | awk '{print $2}'`
echo $PID

if [ e$PID != "e" ]
then
    echo "JBoss SERVER - $SERVER_NAME is already RUNNING..."
    exit;
fi

UNAME=`id -u -n`
if [ e$UNAME != "e$JBOSS_USER" ]
then
    echo "Use $JBOSS_USER account to start JBoss SERVER - $SERVER_NAME..."
    exit;
fi

echo $JAVA_OPTS

if [ ! -d "$JBOSS_LOG_DIR/nohup" ];
then
    mkdir -p $JBOSS_LOG_DIR/nohup
fi  

if [ ! -d "$JBOSS_LOG_DIR/gclog" ];
then
    mkdir -p $JBOSS_LOG_DIR/gclog
fi  

if [ ! -d "$JBOSS_LOG_DIR/heapdump" ];
then
    mkdir -p $JBOSS_LOG_DIR/heapdump
fi  

mv $JBOSS_LOG_DIR/nohup/$SERVER_NAME.out $JBOSS_LOG_DIR/nohup/$SERVER_NAME.out.$DATE

rm -rf tmp/*

export JAVA_OPTS="$AGENT_OPTS $JAVA_OPTS"

# mod_jk Turn OFF
if [ e$1 = "ewait" ]
then
    echo ""
    for HTTPD_HOST in "${HTTPD_HOSTS[@]}"
    do
        echo "<<< Turn-OFF mod_jk Worker $SERVER_NAME in $LB_WORKER [$HTTPD_HOST]"
        if [ "`curl --silent --show-error --connect-timeout 1 -I \"http://$HTTPD_HOST:$APACHE_PORT/jkstatus?cmd=update&w=$LB_WORKER&sw=$SERVER_NAME&vwa=2\" | egrep '404|500|503'`" != "" ]
        then
            echo "<<< Error"
        else
            echo "<<< Done"
        fi
    done
fi

#nohup $JBOSS_HOME/bin/standalone.sh -DSERVER=$SERVER_NAME -b $BIND_ADDR -u $MULTICAST_ADDR -P=$DOMAIN_BASE/$SERVER_NAME/env.properties -c $CONFIG_FILE >> $SERVER_NAME.out 2>&1 &
nohup $JBOSS_HOME/bin/standalone.sh -DSERVER=$SERVER_NAME -P=$DOMAIN_BASE/$SERVER_NAME/env.properties -c $CONFIG_FILE >> $JBOSS_LOG_DIR/nohup/$SERVER_NAME.out 2>&1 &

if [ e$1 = "etail" ]
then
    tail -f $JBOSS_LOG_DIR/nohup/$SERVER_NAME.out
fi

if [ e$1 = "ewait" ]
then
# ex) ./start.sh wait /session
    export CONTEXT_NAME=$2

    let HTTP_PORT=8080+$PORT_OFFSET

    echo ""
    echo "Check $HTTP_PORT port ready on $BIND_ADDR "
    while [ `netstat -an | grep :$HTTP_PORT | grep LISTEN | wc | awk '{print $1}'` != 1 ]; do
            echo -ne "."
            sleep 1
    done

    echo ""
    echo "Check WAS Context Ready http://$BIND_ADDR:$HTTP_PORT$CONTEXT_NAME"

    until [ "`curl --silent --show-error --connect-timeout 1 -I http://$BIND_ADDR:$HTTP_PORT$CONTEXT_NAME | egrep '200|302'`" != "" ];
    do
            echo -ne "."
            sleep 1
    done
    echo ""

    # mod_jk turn ON
    for HTTPD_HOST in "${HTTPD_HOSTS[@]}"
    do
        echo ">>> Turn-ON mod_jk Worker $SERVER_NAME in $LB_WORKER [$HTTPD_HOST]"
        if [ "`curl --silent --show-error --connect-timeout 1 -I \"http://$HTTPD_HOST:$APACHE_PORT/jkstatus?cmd=update&w=$LB_WORKER&sw=$SERVER_NAME&vwa=0\" | egrep '404|500|503'`" != "" ]
        then
            echo ">>> Error"
        else
            echo ">>> Done"
        fi
    done
fi
